import express from 'express';

const app = express();
const PORT = 3000; 


app.get('/check-score', (req, res) => {
    const score = req.query.score;
    if (score < 50) {
        // 1. Set the status code to 400 (Bad Request) and send a JSON error
        res.status(400).json({ error: "Score too low" });
    } else {
        // 2. Send a successful 200 status with a message
        res.status(200).send("You passed!");
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});