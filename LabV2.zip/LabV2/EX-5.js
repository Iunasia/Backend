import express from 'express';

const app = express();
const PORT = 3000; 
const simpleGuard = (req, res, next) => {
    console.log("Someone is trying to access a route...");
    // 1. What function must you call to let the request continue?
    next();
};
// 2. Apply the middleware globally
app.use(simpleGuard);
app.get('/protected', (req, res) => {
    res.send('You passed the guard!');
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});