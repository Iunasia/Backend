// courseFilter.js - Filtering logic
export function filterCourses(courses, dept, query) {
    let filtered = courses.filter(course => 
        course.department.toUpperCase() === dept.toUpperCase()
    );

    // Level filter
    if (query.level) {
        filtered = filtered.filter(course => 
            course.level.toLowerCase() === query.level.toLowerCase()
        );
    }

    // Credits range filter
    if (query.minCredits) {
        const minCredits = parseInt(query.minCredits, 10);
        if (!isNaN(minCredits)) {
            filtered = filtered.filter(course => course.credits >= minCredits);
        }
    }

    if (query.maxCredits) {
        const maxCredits = parseInt(query.maxCredits, 10);
        if (!isNaN(maxCredits)) {
            filtered = filtered.filter(course => course.credits <= maxCredits);
        }
    }

    // Credits exact match
    if (query.credits) {
        const credits = parseInt(query.credits, 10);
        if (!isNaN(credits)) {
            filtered = filtered.filter(course => course.credits === credits);
        }
    }

    // Semester filter
    if (query.semester) {
        filtered = filtered.filter(course => 
            course.semester.toLowerCase() === query.semester.toLowerCase()
        );
    }

    // Instructor partial match
    if (query.instructor) {
        const searchTerm = query.instructor.toLowerCase();
        filtered = filtered.filter(course => 
            course.instructor.toLowerCase().includes(searchTerm)
        );
    }

    return filtered;
}