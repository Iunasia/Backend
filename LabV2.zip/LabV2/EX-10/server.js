// server.js - Main server with middleware (ES Module version)
import express from 'express';
import logger from './logger.js';
import validateQuery from './validateQuery.js';
import authenticateToken from './auth.js'; // Bonus Q3
import { courses } from './coursesData.js';
import { filterCourses } from './courseFilter.js';

const app = express();
const PORT = 3000;

// Q1: Apply logger middleware globally
app.use(logger);

// Optional: Apply authentication globally (uncomment for global auth)
// app.use(authenticateToken);

// Root endpoint
app.get('/', (req, res) => {
    const departments = [...new Set(courses.map(c => c.department))];
    res.json({
        message: "Course Records API with Middleware",
        available_departments: departments,
        middleware_active: {
            logger: "Global - logs all requests",
            validation: "Route-specific - validates minCredits/maxCredits",
            auth: "Optional - token-based authentication (use ?token=xyz123)"
        },
        example_queries: [
            "GET /departments/CSE/courses",
            "GET /departments/CSE/courses?level=undergraduate",
            "GET /departments/CSE/courses?minCredits=4",
            "GET /departments/CSE/courses?instructor=smithsemeister",
            "GET /departments/CSE/courses?token=xyz123 (if auth enabled)"
        ]
    });
});

// Q2 & Q3: Main route with validation middleware and optional authentication
// Apply validateQuery middleware only to this route
// To enable authentication, uncomment authenticateToken
app.get('/departments/:dept/courses', 
    validateQuery,     // Q2: Route-specific validation middleware
    // authenticateToken,  // Q3 Bonus: Uncomment to enable token authentication
    (req, res) => {
        const { dept } = req.params;
        
        // Filter courses based on query parameters
        const filteredCourses = filterCourses(courses, dept, req.query);
        
        // Return results with metadata
        res.json({
            results: filteredCourses,
            meta: {
                total: filteredCourses.length,
                department: dept.toUpperCase(),
                filters_applied: {
                    level: req.query.level || null,
                    minCredits: req.query.minCredits || null,
                    maxCredits: req.query.maxCredits || null,
                    credits: req.query.credits || null,
                    semester: req.query.semester || null,
                    instructor: req.query.instructor || null
                }
            }
        });
    }
);

// Bonus: Additional route to show all courses (with optional auth)
app.get('/courses', 
    // authenticateToken, // Uncomment to protect this route
    (req, res) => {
        res.json({
            total: courses.length,
            courses: courses
        });
    }
);

// Error handling middleware (optional)
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}/contact-us`);
});