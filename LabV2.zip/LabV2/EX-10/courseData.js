// coursesData.js - Course database
export const courses = [
    {
        "id": "CSE101",
        "title": "Introduction to Computer Science",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Klingy",
        "semester": "fall"
    },
    {
        "id": "CSE102",
        "title": "Data Structures & Algorithms",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 4,
        "instructor": "Dr. Klingy",
        "semester": "fall"
    },
    {
        "id": "CSE201",
        "title": "Database Systems",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Smith",
        "semester": "spring"
    },
    {
        "id": "CSE301",
        "title": "Operating Systems",
        "department": "CSE",
        "level": "graduate",
        "credits": 4,
        "instructor": "Dr. Johnson",
        "semester": "fall"
    },
    {
        "id": "CSE401",
        "title": "Machine Learning",
        "department": "CSE",
        "level": "graduate",
        "credits": 4,
        "instructor": "Dr. Smithsemeister",
        "semester": "spring"
    },
    {
        "id": "ECE101",
        "title": "Circuits",
        "department": "ECE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Brown",
        "semester": "fall"
    },
    {
        "id": "MATH201",
        "title": "Linear Algebra",
        "department": "MATH",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Wilson",
        "semester": "spring"
    }
];