// auth.js - Token-based authentication middleware (Bonus Q3)
function authenticateToken(req, res, next) {
    const token = req.query.token;

    if (!token) {
        return res.status(401).json({ 
            error: 'Unauthorized: Missing token parameter' 
        });
    }

    if (token !== 'xyz123') {
        return res.status(401).json({ 
            error: 'Unauthorized: Invalid token' 
        });
    }

    next();
}

export default authenticateToken;