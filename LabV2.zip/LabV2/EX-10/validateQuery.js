// validateQuery.js - Middleware to validate query parameters (Q2)
function validateQuery(req, res, next) {
    const { minCredits, maxCredits } = req.query;

    // Helper to check if a value is a valid integer
    const isValidInteger = (val) => /^\d+$/.test(val) && Number.isInteger(parseFloat(val));

    // Validate minCredits if present
    if (minCredits !== undefined && !isValidInteger(minCredits)) {
        return res.status(400).json({ 
            error: 'minCredits must be a valid integer' 
        });
    }

    // Validate maxCredits if present
    if (maxCredits !== undefined && !isValidInteger(maxCredits)) {
        return res.status(400).json({ 
            error: 'maxCredits must be a valid integer' 
        });
    }

    // Validate that minCredits is not greater than maxCredits
    if (minCredits !== undefined && maxCredits !== undefined) {
        const min = parseInt(minCredits, 10);
        const max = parseInt(maxCredits, 10);
        if (min > max) {
            return res.status(400).json({ 
                error: 'minCredits cannot be greater than maxCredits' 
            });
        }
    }

    next();
}

export default validateQuery;