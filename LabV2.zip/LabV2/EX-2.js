import express from 'express';

const app = express();
const PORT = 3000; 

app.get('/',(req,res)=>{
    res.send("The foundation is solid!");
});
// Start the server on port 30

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});