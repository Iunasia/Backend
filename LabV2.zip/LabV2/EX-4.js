import express from 'express';

const app = express();
const PORT = 3000; 

// Test URL: http://localhost:3000/shop?item=laptop&price=1000
app.get('/shop', (req, res) => {
    // 1. Extract 'item' and 'price' from the query string
    const itemName = req.query.item;
    const itemPrice = req.query.price;

    res.json({
        product: itemName,
        cost: itemPrice
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});