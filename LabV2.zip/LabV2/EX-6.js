import express from 'express';

const app = express();
const PORT = 3000; 

app.use(express.json());
app.post('/echo', (req, res) => {
    // 2. Access the data sent in the request body
    const receivedData = req.body;
    res.json({
        message: "I received your data!",
        data: receivedData
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});