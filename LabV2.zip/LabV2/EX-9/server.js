// server.js - Course Records API with ES Modules
import express from 'express';

const app = express();
const PORT = 3000;

// Sample course data
const courses = [
    {
        "id": "CSE101",
        "title": "Introduction to Computer Science",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Klingy",
        "semester": "fall"
    },
    {
        "id": "CSE102",
        "title": "Data Structures & Algorithms",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 4,
        "instructor": "Dr. Klingy",
        "semester": "fall"
    },
    {
        "id": "CSE201",
        "title": "Database Systems",
        "department": "CSE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Smith",
        "semester": "spring"
    },
    {
        "id": "CSE301",
        "title": "Operating Systems",
        "department": "CSE",
        "level": "graduate",
        "credits": 4,
        "instructor": "Dr. Johnson",
        "semester": "fall"
    },
    {
        "id": "CSE401",
        "title": "Machine Learning",
        "department": "CSE",
        "level": "graduate",
        "credits": 4,
        "instructor": "Dr. Smithsemeister",
        "semester": "spring"
    },
    {
        "id": "ECE101",
        "title": "Circuits",
        "department": "ECE",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Brown",
        "semester": "fall"
    },
    {
        "id": "MATH201",
        "title": "Linear Algebra",
        "department": "MATH",
        "level": "undergraduate",
        "credits": 3,
        "instructor": "Dr. Wilson",
        "semester": "spring"
    }
];

// Helper function to filter courses based on query parameters
function filterCourses(courses, dept, query) {
    let filtered = courses.filter(course => 
        course.department.toUpperCase() === dept.toUpperCase()
    );

    // Level filter
    if (query.level) {
        filtered = filtered.filter(course => 
            course.level.toLowerCase() === query.level.toLowerCase()
        );
    }

    // Credits filter (minCredits and maxCredits)
    if (query.minCredits) {
        const minCredits = parseInt(query.minCredits, 10);
        if (!isNaN(minCredits)) {
            filtered = filtered.filter(course => course.credits >= minCredits);
        }
    }

    if (query.maxCredits) {
        const maxCredits = parseInt(query.maxCredits, 10);
        if (!isNaN(maxCredits)) {
            filtered = filtered.filter(course => course.credits <= maxCredits);
        }
    }

    // If both min and max are present, validate they make sense (Q4 - Edge Case)
    if (query.minCredits && query.maxCredits) {
        const minCredits = parseInt(query.minCredits, 10);
        const maxCredits = parseInt(query.maxCredits, 10);
        if (!isNaN(minCredits) && !isNaN(maxCredits) && minCredits > maxCredits) {
            return { error: "Invalid credit range: minCredits cannot be greater than maxCredits", results: [], meta: { total: 0 } };
        }
    }

    // Credits exact match (if credits parameter is provided)
    if (query.credits) {
        const credits = parseInt(query.credits, 10);
        if (!isNaN(credits)) {
            filtered = filtered.filter(course => course.credits === credits);
        }
    }

    // Semester filter
    if (query.semester) {
        filtered = filtered.filter(course => 
            course.semester.toLowerCase() === query.semester.toLowerCase()
        );
    }

    // Instructor partial match (case-insensitive)
    if (query.instructor) {
        const searchTerm = query.instructor.toLowerCase();
        filtered = filtered.filter(course => 
            course.instructor.toLowerCase().includes(searchTerm)
        );
    }

    return { results: filtered, meta: { total: filtered.length } };
}

// Q1 & Q2 & Q3: Main route with filtering
app.get('/departments/:dept/courses', (req, res) => {
    const { dept } = req.params;
    const query = req.query;
    
    // Filter courses
    const result = filterCourses(courses, dept, query);
    
    // Check if there was an error (invalid credit range)
    if (result.error) {
        return res.status(400).json({ error: result.error });
    }
    
    // Return the filtered results
    res.json(result);
});

// Bonus: Root endpoint to show available departments
app.get('/', (req, res) => {
    const departments = [...new Set(courses.map(c => c.department))];
    res.json({
        message: "Course Records API",
        available_departments: departments,
        example_queries: [
            "/departments/CSE/courses",
            "/departments/CSE/courses?level=undergraduate",
            "/departments/CSE/courses?minCredits=4",
            "/departments/CSE/courses?instructor=smithsemeister",
            "/departments/CSE/courses?level=fall",
            "/departments/CSE/courses?minCredits=4&maxCredits=2" // This will return error
        ]
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Course API Server running on http://localhost:${PORT}`);
    console.log(`\nTest these URLs:`);
    console.log(`1. http://localhost:${PORT}/departments/CSE/courses`);
    console.log(`2. http://localhost:${PORT}/departments/CSE/courses?level=undergraduate`);
    console.log(`3. http://localhost:${PORT}/departments/CSE/courses?minCredits=4`);
    console.log(`4. http://localhost:${PORT}/departments/CSE/courses?instructor=smithsemeister`);
    console.log(`5. http://localhost:${PORT}/departments/CSE/courses?level=fall`);
    console.log(`\nEdge Case Test:`);
    console.log(`- http://localhost:${PORT}/departments/CSE/courses?minCredits=4&maxCredits=2 (should return 400 error)`);
});