import express from 'express';

const app = express();
const PORT = 3000; 

// Task: Make this route accept any student ID in the URL
app.get('/student/:studentId', (req, res) => {
    // 1. Extract the ID from the request parameters
    const studentId = req.params.studentId;

    res.send(`Searching for student with ID: ${studentId}`);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});