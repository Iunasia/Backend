// server.js
import express from 'express';
import fs from 'fs';

const app = express();
const PORT = 3000;

// Middleware to log requests
app.use((req, res, next) => {
    console.log(`Received ${req.method} request for ${req.url}`);
    next();
});

// Routes
app.get('/', (req, res) => {
    res.send('Hello, CADT student!');
});

app.get('/about', (req, res) => {
    res.send('About us: at CADT, we love node.js!');
});

app.get('/contact-us', (req, res) => {
    res.send('You can reach us via email...');
});

app.get('/products', (req, res) => {
    res.json('Buy one get one…');
});

app.get('/projects', (req, res) => {
    res.json('Here are our awesome projects');
});

// 404 handler for unmatched routes
app.use((req, res) => {
    res.status(404).send('404 Not Found');
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}/contact-us`);
});