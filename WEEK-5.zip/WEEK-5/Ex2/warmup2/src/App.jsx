// 1. Import the correct file path
import FetchOnce from './fetchOnce.jsx'; 

function App() {
  return (
    <div>
      <h1>My Full-Stack articles</h1>
      <hr />
      {/* 2. RENDER THE COMPONENT HERE */}
      <FetchOnce /> 
    </div>
  );
}

export default App;