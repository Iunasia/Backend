import { Routes, Route } from 'react-router-dom';
import ArticleDetail from './ArticleDetail.jsx';

function App() {
  return (
    <Routes>
      <Route path="/articles/:id" element={<ArticleDetail />} />
    </Routes>
  );
}

export default App;