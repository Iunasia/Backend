import axios from "axios";

function App() {
  console.log("Axios version:", axios.VERSION);
  console.log('Default baseURL:', axios.defaults.baseURL);

  return <h1>Axios is ready!</h1>

};

export default App;