import express from 'express';
const router = express.Router();

// Example route: GET /users/:id
router.get('/:id', (req, res) => {
  const { id } = req.params;
  res.json(`requested user with ID: ${id}`);
});

export default router;