import express from 'express';
import taskRoutes from './routes/taskRoutes.js';

const app = express();
app.use(express.json());

app.use('/tasks', taskRoutes);   // mount tasks router

app.listen(3000, () => console.log('Mini modular app running on http://localhost:3000'));