import express from 'express';
import helloRoutes from './routes/helloRoutes.js';

const app = express();

// Mount the router under the path /hello
app.use('/hello', helloRoutes);

app.listen(3000, () => console.log('Server running on port 3000'));