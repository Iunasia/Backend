import express from 'express';
import bookRoutes from '../warmup2/routes/bookRoutes.js';

const app = express();
app.use(express.json());      // <-- enable JSON body parsing
app.use('/books', bookRoutes);   // <-- mount router

app.listen(3000);