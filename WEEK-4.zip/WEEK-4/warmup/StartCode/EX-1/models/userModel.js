let users = [
  { id: 1, name: 'Alice', email: 'alice@example.com' },
  { id: 2, name: 'Bob', email: 'bob@example.com' }
];

export const getAllUsers = () => users;

export const findUserById = (id) => users.find(u => u.id === id);

export const createUser = (userData) => {
  const newUser = { id: users.length + 1, ...userData };
  users.push(newUser);
  return newUser;
};

export const updateUser = (id, updateData) => {
  const user = findUserById(id);
  if (!user) return null;
  user.name = updateData.name || user.name;
  user.email = updateData.email || user.email;
  return user;
};

export const deleteUser = (id) => {
  const index = users.findIndex(u => u.id === id);
  if (index === -1) return false;
  users.splice(index, 1);
  return true;
};