import * as userModel from '../models/userModel.js';

export const getUsers = (req, res) => {
  res.json(userModel.getAllUsers());
};

export const getUserById = (req, res) => {
  const id = parseInt(req.params.id);
  const user = userModel.findUserById(id);
  
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  res.json(user);
};

export const createUser = (req, res) => {
  const newUser = userModel.createUser(req.body);
  res.status(201).json(newUser);
};

export const updateUser = (req, res) => {
  const id = parseInt(req.params.id);
  const updatedUser = userModel.updateUser(id, req.body);
  
  if (!updatedUser) {
    return res.status(404).json({ message: 'User not found' });
  }
  res.json(updatedUser);
};

export const deleteUser = (req, res) => {
  const id = parseInt(req.params.id);
  const deleted = userModel.deleteUser(id);
  
  if (!deleted) {
    return res.status(404).json({ message: 'User not found' });
  }
  res.status(204).send();
};