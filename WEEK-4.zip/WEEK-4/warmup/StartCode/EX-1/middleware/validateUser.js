export const validateUser = (req, res, next) => {
  const { name, email } = req.body;
  
  if (!name || !email) {
    return res.status(400).json({ 
      message: 'Name and email are required fields' 
    });
  }
  
  if (!email.includes('@')) {
    return res.status(400).json({ 
      message: 'Valid email address is required' 
    });
  }
  
  next();
};