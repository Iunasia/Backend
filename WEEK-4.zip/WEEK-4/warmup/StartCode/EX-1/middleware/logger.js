
import fs from 'fs';

const logger = (req, res, next) => {
  const logLine = `${new Date().toISOString()} - ${req.method} ${req.url}\n`;
  fs.appendFile('logs/access.log', logLine, (err) => {
    if (err) console.error('Logging failed:', err);
  });
  next();
};

export default logger;