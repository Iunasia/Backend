import express from 'express';
import articleRoutes from './routes/articleRoutes.js';
import journalistRoutes from './routes/journalistRoutes.js';
import categoryRoutes from './routes/categoryRoutes.js';
import logger from './middleware/logger.js';

const app = express();

app.use(express.json());
app.use(logger);

app.use('/articles', articleRoutes);
app.use('/journalists', journalistRoutes);
app.use('/categories', categoryRoutes);

app.listen(3000, () => {
  console.log('RESTful API running on port 3000');
});