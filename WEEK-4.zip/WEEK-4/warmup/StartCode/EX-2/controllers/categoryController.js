import * as categoryModel from '../models/categoryModel.js';
import * as articleModel from '../models/articleModel.js';

export const getCategories = (req, res) => {
  res.json(categoryModel.getAll());
};

export const getCategoryById = (req, res) => {
  const id = parseInt(req.params.id);
  const category = categoryModel.findById(id);
  if (!category) {
    return res.status(404).json({ message: 'Category not found' });
  }
  res.json(category);
};

export const createCategory = (req, res) => {
  const newCategory = categoryModel.create(req.body);
  res.status(201).json(newCategory);
};

export const updateCategory = (req, res) => {
  const id = parseInt(req.params.id);
  const updated = categoryModel.update(id, req.body);
  if (!updated) {
    return res.status(404).json({ message: 'Category not found' });
  }
  res.json(updated);
};

export const deleteCategory = (req, res) => {
  const id = parseInt(req.params.id);
  const deleted = categoryModel.remove(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Category not found' });
  }
  res.status(204).send();
};

export const getArticlesByCategory = (req, res) => {
  const id = parseInt(req.params.id);
  const category = categoryModel.findById(id);
  if (!category) {
    return res.status(404).json({ message: 'Category not found' });
  }
  const articles = articleModel.findByCategory(id);
  res.json(articles);
};