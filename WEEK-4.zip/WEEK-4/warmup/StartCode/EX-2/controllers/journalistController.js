import * as journalistModel from '../models/journalistModel.js';
import * as articleModel from '../models/articleModel.js';

export const getJournalists = (req, res) => {
  res.json(journalistModel.getAll());
};

export const getJournalistById = (req, res) => {
  const id = parseInt(req.params.id);
  const journalist = journalistModel.findById(id);
  if (!journalist) {
    return res.status(404).json({ message: 'Journalist not found' });
  }
  res.json(journalist);
};

export const createJournalist = (req, res) => {
  const newJournalist = journalistModel.create(req.body);
  res.status(201).json(newJournalist);
};

export const updateJournalist = (req, res) => {
  const id = parseInt(req.params.id);
  const updated = journalistModel.update(id, req.body);
  if (!updated) {
    return res.status(404).json({ message: 'Journalist not found' });
  }
  res.json(updated);
};

export const deleteJournalist = (req, res) => {
  const id = parseInt(req.params.id);
  const deleted = journalistModel.remove(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Journalist not found' });
  }
  res.status(204).send();
};

export const getArticlesByJournalist = (req, res) => {
  const id = parseInt(req.params.id);
  const journalist = journalistModel.findById(id);
  if (!journalist) {
    return res.status(404).json({ message: 'Journalist not found' });
  }
  const articles = articleModel.findByJournalist(id);
  res.json(articles);
};