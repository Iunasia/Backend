import * as articleModel from '../models/articleModel.js';

export const getArticles = (req, res) => {
  res.json(articleModel.getAll());
};

export const getArticleById = (req, res) => {
  const id = parseInt(req.params.id);
  const article = articleModel.findById(id);
  if (!article) {
    return res.status(404).json({ message: 'Article not found' });
  }
  res.json(article);
};

export const createArticle = (req, res) => {
  const newArticle = articleModel.create(req.body);
  res.status(201).json(newArticle);
};

export const updateArticle = (req, res) => {
  const id = parseInt(req.params.id);
  const updated = articleModel.update(id, req.body);
  if (!updated) {
    return res.status(404).json({ message: 'Article not found' });
  }
  res.json(updated);
};

export const deleteArticle = (req, res) => {
  const id = parseInt(req.params.id);
  const deleted = articleModel.remove(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Article not found' });
  }
  res.status(204).send();
};