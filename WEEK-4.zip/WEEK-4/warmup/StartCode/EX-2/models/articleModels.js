let articles = [
  { id: 1, title: 'First Article', content: 'Content here', journalistId: 1, categoryId: 1 },
  { id: 2, title: 'Second Article', content: 'More content', journalistId: 2, categoryId: 2 }
];

export const getAll = () => articles;
export const findById = (id) => articles.find(a => a.id === id);
export const create = (data) => {
  const newArticle = { id: articles.length + 1, ...data };
  articles.push(newArticle);
  return newArticle;
};
export const update = (id, data) => {
  const index = articles.findIndex(a => a.id === id);
  if (index === -1) return null;
  articles[index] = { ...articles[index], ...data };
  return articles[index];
};
export const remove = (id) => {
  const index = articles.findIndex(a => a.id === id);
  if (index === -1) return false;
  articles.splice(index, 1);
  return true;
};
export const findByJournalist = (journalistId) => 
  articles.filter(a => a.journalistId === journalistId);
export const findByCategory = (categoryId) => 
  articles.filter(a => a.categoryId === categoryId);