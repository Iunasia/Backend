let categories = [
  { id: 1, name: 'Technology' },
  { id: 2, name: 'Sports' }
];

export const getAll = () => categories;
export const findById = (id) => categories.find(c => c.id === id);
export const create = (data) => {
  const newCategory = { id: categories.length + 1, ...data };
  categories.push(newCategory);
  return newCategory;
};
export const update = (id, data) => {
  const index = categories.findIndex(c => c.id === id);
  if (index === -1) return null;
  categories[index] = { ...categories[index], ...data };
  return categories[index];
};
export const remove = (id) => {
  const index = categories.findIndex(c => c.id === id);
  if (index === -1) return false;
  categories.splice(index, 1);
  return true;
};