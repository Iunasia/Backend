let journalists = [
  { id: 1, name: 'John Doe', email: 'john@example.com' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
];

export const getAll = () => journalists;
export const findById = (id) => journalists.find(j => j.id === id);
export const create = (data) => {
  const newJournalist = { id: journalists.length + 1, ...data };
  journalists.push(newJournalist);
  return newJournalist;
};
export const update = (id, data) => {
  const index = journalists.findIndex(j => j.id === id);
  if (index === -1) return null;
  journalists[index] = { ...journalists[index], ...data };
  return journalists[index];
};
export const remove = (id) => {
  const index = journalists.findIndex(j => j.id === id);
  if (index === -1) return false;
  journalists.splice(index, 1);
  return true;
};