import { findProductById} from './models/productModel.js';
import { getAllProducts } from './models/productModel.js';
import express from 'express';

const app = express();
app.use(express.json());
app.use('/products', productRoutes2);

console.log(getAllProducts());
console.log(findProductById(1));