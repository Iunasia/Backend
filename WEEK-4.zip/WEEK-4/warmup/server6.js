import logger from './middleware/logger.js';
import express from 'express';

const app = express();

app.use(logger);   // <-- apply logger to every request


app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});